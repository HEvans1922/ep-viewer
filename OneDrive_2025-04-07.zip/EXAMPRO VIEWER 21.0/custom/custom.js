function close_window() {
    if (confirm("Close Window?")) {
        close();
    }
}

var reqid = "null";